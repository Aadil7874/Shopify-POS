import React from 'react';


const viewInventory = () => {
  return (
    <div>viewInventory Page SAAAA   </div>
  )
}

export default viewInventory