// import Link from "next/link";
// import Image from "next/image";
// import myImage from './images/png/image 1.png';

export default function Home() {
  return (
    <>
      <h1 className="flex justify-center text-2xl">View Inventory - Top Components</h1>
      <section>
        <div className="bg-blue-400 justify-center">
          {/* Top 4 components */}
          <div className="flex flex-wrap gap-[19px] mb-[19px] justify-center">
            {" "}
            {/* All four components container */}
            <div className="w-[186px] h-36 rounded-xl inline-flex justify-center items-center bg-white">
              <img src="/image 1.png" alt="image 1" />
            </div>
            {/* Top 2nd comp */}
            <div className="w-[410px] h-[145px]  rounded-xl bg-white px-[15px] py-[11px] ">
              <div className="flex justify-between flex-col w-full h-full">
                <div className="inline-flex justify-between items-center">
                  <div className="text-xs">
                    <span className="text-[#8B8D97] pr-1">Last Order</span>
                    <span className="text-[#2C2D33]">12 Sep 2022</span>
                  </div>
                  <div>
                    <div className=" flex justify-center text-xs py-[4px] px-[11px] w-[78px] h-[23px] rounded-lg bg-[#32936F42]">
                      <span className="text-[#519C66]">Published</span>
                    </div>
                  </div>
                </div>
                {/*  */}
                <div className="inline-flex justify-between">
                  <div className=" w-2/4">
                    <div className="text-[#8B8D97] text-xs">Price</div>
                    <div className=" font-[500] text-sm">₦25,000.00</div>
                  </div>
                  <div className="w-2/4">
                    <div className="text-[#8B8D97] text-xs">In-Stock</div>
                    <div className="text-sm  font-[500]">14</div>
                  </div>
                </div>
              </div>
            </div>
            {/* Top 3rd Comp */}
            <div className=" w-[330px] h-[145px] rounded-xl bg-white px-[15px] py-[11px] flex justify-between flex-col">
              <div className="inline-flex justify-between items-center">
                <div className="text-xs">
                  <img src="/dshbrdicon.png" alt="" />
                </div>
                <div className="flex gap-[7px]">
                  <p className="text-[#8B8D97] text-xs">All-time</p>
                  <span>
                    <img src="/fi_chevron-down.svg" alt="chevron down" />
                  </span>
                </div>
              </div>
              {/*  */}
              <div className="inline-flex justify-between">
                <div className=" w-full">
                  <div className="text-[#8B8D97] text-[14px]">Total Orders</div>
                  <div className=" font-[500] text-xl">₦50,000.00</div>
                </div>
                {/* <div className="w-2/4">
                    <div className="text-[#8B8D97] text-xs">In-Stock</div>
                    <div className="text-sm  font-[500]">14</div>
                  </div> */}
              </div>
            </div>
            {/* Top 4th comp */}
            <div className=" w-[328px] h-[145px] px-[15px] py-[11px] rounded-xl bg-white flex flex-col justify-between">
              <div className="inline-flex justify-between items-center">
                <div className="text-xs">
                  <img src="/icon-eye.png" alt="" />
                </div>
                <div className="flex gap-[7px]">
                  <p className="text-[#8B8D97] text-xs">All-time</p>
                  <span>
                    <img src="/fi_chevron-down.svg" alt="" />
                  </span>
                </div>
              </div>
              {/*  */}
              <div className="inline-flex justify-between items-center">
                <div className=" w-2/4">
                  <div className="text-[#8B8D97] text-[14px]">Views</div>
                  <div className=" font-[500] text-xl">1,200</div>
                </div>
                <div className="w-2/4">
                  <div className="text-[#8B8D97] text-xs">Favourite</div>
                  <div className="text-xl font-[500]">23</div>
                </div>
              </div>
            </div>
          </div>
          {/* Down 2 components */}
          <div className="flex gap-[19px] justify-center">
            <div className="w-[646px] h-[145px] px-[15px] py-[10px] rounded-xl bg-white flex flex-col justify-between">
              <div className="inline-flex justify-between items-center">
                <div className="text-xs">
                  <img src="/bag_type_icon.png" alt="" />
                </div>
                <div className="flex gap-[7px]">
                  <p className="text-[#8B8D97] text-xs">All-time</p>
                  <span>
                    <img src="/fi_chevron-down.svg" alt="" />
                  </span>
                </div>
              </div>
              {/*  */}
              <div className="inline-flex justify-between items-center">
                <div className=" w-2/4">
                  <div className="text-[#8B8D97] text-[14px]">All Orders</div>
                  <div className=" font-[500] text-xl">1</div>
                </div>
                <div className="w-2/4">
                  <div className="text-[#8B8D97] text-xs">Pending</div>
                  <div className="text-xl font-[500]">0</div>
                </div>
                <div className="w-2/4">
                  <div className="text-[#8B8D97] text-xs">Completed</div>
                  <div className="text-xl font-[500]">1</div>
                </div>
              </div>
            </div>
            <div className="w-[646px] h-[145px] rounded-xl px-[15px] py-[10px] bg-white flex flex-col justify-between">
              <div className="inline-flex justify-between items-center">
                <div className="text-xs">
                  <img src="/bag_type_icon.png" alt="" />
                </div>
                <div className="flex gap-[7px]">
                  <p className="text-[#8B8D97] text-xs">All-time</p>
                  <span>
                    <img src="/fi_chevron-down.svg" alt="" />
                  </span>
                </div>
              </div>
              {/*  */}
              <div className="inline-flex justify-between items-center">
                <div className=" w-2/4">
                  <div className="text-[#8B8D97] text-[14px]">Canceled</div>
                  <div className=" font-[500] text-xl">0</div>
                </div>
                <div className="w-2/4">
                  <div className="text-[#8B8D97] text-xs">Returned</div>
                  <div className="text-xl font-[500]">0</div>
                </div>
                <div className="w-2/4">
                  <div className="text-[#8B8D97] text-xs">Damage</div>
                  <div className="text-xl font-[500]">0</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* <Link href={"./components/inventoryManager/viewInventory/page.js"}>
      view Inventory
    </Link>
    <a href="./components/inventoryManager/viewInventory/page.js">
      A mai se view inventory
    </a> */}
    </>
    // <main className="flex min-h-screen flex-col items-center justify-between p-24">
    //   <div className="z-10 max-w-5xl w-full items-center justify-between font-mono text-sm lg:flex">
    //     <p className="fixed left-0 top-0 flex w-full justify-center border-b border-gray-300 bg-gradient-to-b from-zinc-200 pb-6 pt-8 backdrop-blur-2xl dark:border-neutral-800 dark:bg-zinc-800/30 dark:from-inherit lg:static lg:w-auto  lg:rounded-xl lg:border lg:bg-gray-200 lg:p-4 lg:dark:bg-zinc-800/30">
    //       Get started by editing&nbsp;
    //       <code className="font-mono font-bold">src/app/page.js</code>
    //     </p>
    //     <div className="fixed bottom-0 left-0 flex h-48 w-full items-end justify-center bg-gradient-to-t from-white via-white dark:from-black dark:via-black lg:static lg:h-auto lg:w-auto lg:bg-none">
    //       <a
    //         className="pointer-events-none flex place-items-center gap-2 p-8 lg:pointer-events-auto lg:p-0"
    //         href="https://vercel.com?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
    //         target="_blank"
    //         rel="noopener noreferrer"
    //       >
    //         By{" "}
    //         <Image
    //           src="/my-app/public/inventoryManager/png/Logo.png"
    //           alt="Vercel Logo"
    //           className="dark:invert"
    //           width={100}
    //           height={24}
    //           priority
    //         />
    //       </a>
    //     </div>
    //   </div>

    //   <div className="relative flex place-items-center before:absolute before:h-[300px] before:w-full sm:before:w-[480px] before:-translate-x-1/2 before:rounded-full before:bg-gradient-radial before:from-white before:to-transparent before:blur-2xl before:content-[''] after:absolute after:-z-20 after:h-[180px] after:w-full sm:after:w-[240px] after:translate-x-1/3 after:bg-gradient-conic after:from-sky-200 after:via-blue-200 after:blur-2xl after:content-[''] before:dark:bg-gradient-to-br before:dark:from-transparent before:dark:to-blue-700 before:dark:opacity-10 after:dark:from-sky-900 after:dark:via-[#0141ff] after:dark:opacity-40 before:lg:h-[360px] z-[-1]">
    //     <Image
    //       className="relative dark:drop-shadow-[0_0_0.3rem_#ffffff70] dark:invert"
    //       src="/my-app/public/inventoryManager/svg/fi_chevron-down.svg"
    //       alt="Next.js Logo"
    //       width={180}
    //       height={37}
    //       priority
    //     />
    //   </div>

    //   <div className="mb-32 grid text-center lg:max-w-5xl lg:w-full lg:mb-0 lg:grid-cols-4 lg:text-left">
    //     <a
    //       href="https://nextjs.org/docs?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
    //       className="group rounded-lg border border-transparent px-5 py-4 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       <h2 className={`mb-3 text-2xl font-semibold`}>
    //         Docs{" "}
    //         <span className="inline-block transition-transform group-hover:translate-x-1 motion-reduce:transform-none">
    //           -&gt;
    //         </span>
    //       </h2>
    //       <p className={`m-0 max-w-[30ch] text-sm opacity-50`}>
    //         Find in-depth information about Next.js features and API.
    //       </p>
    //     </a>

    //     <a
    //       href="https://nextjs.org/learn?utm_source=create-next-app&utm_medium=appdir-template-tw&utm_campaign=create-next-app"
    //       className="group rounded-lg border border-transparent px-5 py-4 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800 hover:dark:bg-opacity-30"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       <h2 className={`mb-3 text-2xl font-semibold`}>
    //         Learn{" "}
    //         <span className="inline-block transition-transform group-hover:translate-x-1 motion-reduce:transform-none">
    //           -&gt;
    //         </span>
    //       </h2>
    //       <p className={`m-0 max-w-[30ch] text-sm opacity-50`}>
    //         Learn about Next.js in an interactive course with&nbsp;quizzes!
    //       </p>
    //     </a>

    //     <a
    //       href="https://vercel.com/templates?framework=next.js&utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
    //       className="group rounded-lg border border-transparent px-5 py-4 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       <h2 className={`mb-3 text-2xl font-semibold`}>
    //         Templates{" "}
    //         <span className="inline-block transition-transform group-hover:translate-x-1 motion-reduce:transform-none">
    //           -&gt;
    //         </span>
    //       </h2>
    //       <p className={`m-0 max-w-[30ch] text-sm opacity-50`}>
    //         Explore starter templates for Next.js.
    //       </p>
    //     </a>

    //     <a
    //       href="https://vercel.com/new?utm_source=create-next-app&utm_medium=appdir-template&utm_campaign=create-next-app"
    //       className="group rounded-lg border border-transparent px-5 py-4 transition-colors hover:border-gray-300 hover:bg-gray-100 hover:dark:border-neutral-700 hover:dark:bg-neutral-800/30"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       <h2 className={`mb-3 text-2xl font-semibold`}>
    //         Deploy{" "}
    //         <span className="inline-block transition-transform group-hover:translate-x-1 motion-reduce:transform-none">
    //           -&gt;
    //         </span>
    //       </h2>
    //       <p className={`m-0 max-w-[30ch] text-sm opacity-50 text-balance`}>
    //         Instantly deploy your Next.js site to a shareable URL with Vercel.
    //       </p>
    //     </a>
    //   </div>
    // </main>
  );
}
